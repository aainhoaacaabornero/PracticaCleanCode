/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectocleancode;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;

/**
 *
 * @author ainho
 */
public class Tema8Test {
    
    public void testDivision() {
        String input = "6\n2\n";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);

        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        Main.main(new String[0]);
        assertEquals("Ingrese el primer número:\nIngrese el segundo número:\nEl resultado de la división es: 3\nElemento en la posición 1 del array: 1\nEl array no tiene 6 elementos.\n", outContent.toString());
    }

    public void testDivisionPorCero() {
        String input = "6\n0\n";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);

        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        Main.main(new String[0]);
        assertEquals("Ingrese el primer número:\nIngrese el segundo número:\nError: No se puede dividir entre cero\n", outContent.toString());
    }

    public void testEntradaNoEntera() {
        String input = "a\n2\n";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);

        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        Main.main(new String[0]);
        assertEquals("Ingrese el primer número:\nError: Ingrese un número entero válido.\nIngrese el segundo número:\nEl resultado de la división es: 3\nElemento en la posición 1 del array: 1\nEl array no tiene 6 elementos.\n", outContent.toString());
    }
    // he creado el metodo assetEquals porque me daba error el programa
    private void assertEquals(String ingrese_el_primer_númeroIngrese_el_segund, String toString) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
