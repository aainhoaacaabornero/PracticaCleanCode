/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.proyectocleancode;

import java.util.Scanner;

/**
 *
 * @author ainho
 */
public class Main {

    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        int[] array = {1, 3, 5, 7, 9};

        try {
            System.out.println("Ingrese el primer número:");
            int n1Num = Integer.parseInt(in.next());

            System.out.println("Ingrese el segundo número:");
            int n2Num = Integer.parseInt(in.next());

            if (n2Num == 0) {
                throw new ArithmeticException("No se puede dividir entre cero");
            }

            int resultado = n1Num / n2Num;
            System.out.println("El resultado de la división es: " + resultado);

            // Imprimir la posición 1
            System.out.println("Elemento en la posición 1 del array: " + array[0]);
            // Imprimir la posición 6 (si el array tuviera esa longitud)
            if (array.length >= 6) {
                System.out.println("Elemento en la posición 6 del array: " + array[5]);
            } else {
                System.out.println("El array no tiene 6 elementos.");
            }

        } catch (NumberFormatException e) {
            System.out.println("Error: Ingrese un número entero válido.");
        } catch (ArithmeticException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Error: El índice del array está fuera de rango.");
        }

    }
}
